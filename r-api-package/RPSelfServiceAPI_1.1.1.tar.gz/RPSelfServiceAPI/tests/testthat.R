library(testthat)
library(RPSelfServiceAPI)

test_check("RPSelfServiceAPI")
