#################################################
# Test TAXONOMY                                 #
#                                               #
# Querying the event taxonomy                   #
#################################################

context("Endpoints_Taxonomy")



# ***************************** STREAMING TESTS START *****************************************


########################
# Query Event Taxonomy #
########################
test_that("Query Event Taxonomy", {

  payload_taxonomy = '{
    "topics": [],
    "groups": [],
    "types": [],
    "sub_types": [],
    "properties": [],
    "categories": [
    "earnings-above-expectations",
    "product-recall"
    ]
    }'

  taxonomyData = RP_APITaxonomy(APIHandler = APIHandler, payload = payload_taxonomy)

  cat( paste0("\n*******************************\nTAXONOMY:\n", toString(taxonomyData), "\n*******************************\n") )

  expect_true( is.list(taxonomyData) )
})
