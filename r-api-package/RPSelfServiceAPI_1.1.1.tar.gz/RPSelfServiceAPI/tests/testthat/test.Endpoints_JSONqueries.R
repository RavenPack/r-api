########################################################
# Test entrypoints for REQUESTING DATA IN JSON FORMAT  #
#                                                      #
# It performs 5 tests:                                 #
#   1. Adhoc Request for Daily Data in json            #
#   2. Adhoc Request for Data Granular                 #
#   3. Adhoc Request for Dataset in jSON format        #
#   4. Preview of a dataset                            #
#   5. Preview of a dataset with timezone              #
#                                                      #
########################################################

context("Endpoints_JSONqueries")



####################
# GLOBAL VARIABLES #
####################
# Dataset UUID
# I create a dataset because next tests require a datasetUUID!!
datasetUUID <<- RP_APICreateDataSet(APIHandler = APIHandler, payload = payload_createDS_DF)


# ******************* JSON QUERIES TESTS START **************************************

################################
# Adhoc Request for Daily Data #
################################
test_that("Adhoc Request for Data Daily", {
  payload_jsonfull = '{
  "product": "RPA",
  "product_version": "1.0",
  "frequency": "daily",
  "time_zone": "America/New_York",
  "fields": [
  {
  "average_ess": {
  "avg": {
  "field": "event_sentiment_score"
  }
  }
  }
  ],
  "filters": {
  "and": [
  {
  "RP_ENTITY_ID": {
  "in": [
  "D8442A"
  ]
  }
  },
  {
  "EVENT_RELEVANCE": {
  "eq": 100
  }
  }
  ]
  },
  "having": [],
  "start_date": "2017-03-10 15:30:00",
  "end_date": "2017-03-15 15:30:00"
}'
  data = RP_APIGetFullAdhocJSON(APIHandler = APIHandler, payload = payload_jsonfull)

  cat( paste0("\n*******************************\nJSON DAILY:\n", toString(data), "\n*******************************\n") )

  expect_true( is.data.table(data) )
  expect_true( nrow(data)>0 )
})


###################################
# Adhoc Request for Data Granular #
###################################
test_that("Adhoc Request for Data Granular", {
  payload_jsonfull = '{
  "product": "RPA",
  "product_version": "1.0",
  "frequency": "granular",
  "fields": [
  "TIMESTAMP_UTC",
  "RP_STORY_ID",
  "RP_ENTITY_ID",
  "ENTITY_NAME",
  "EVENT_SENTIMENT_SCORE"
  ],
  "filters": {
  "and": [
  {
  "RP_ENTITY_ID": {
  "in": [
  "D8442A"
  ]
  }
  },
  {
  "EVENT_RELEVANCE": {
  "eq": 100
  }
  }
  ]
  },
  "start_date": "2017-03-10 15:30:00",
  "end_date": "2017-03-15 15:30:00"
}'

  data = RP_APIGetFullAdhocJSON(APIHandler = APIHandler, payload = payload_jsonfull)

  cat( paste0("\n*******************************\nJSON GRANULAR:\n", toString(data), "\n*******************************\n") )

  expect_true( is.data.table(data) )
  expect_true( nrow(data)>0 )
})



# ************ QUERIES TO DATASET ***************


#############################
# Adhoc Request for Dataset #
#############################
test_that("Adhoc Request for Dataset", {

  payload_jsonDS = '{
      "frequency": "daily",
      "fields": [
      {
      "average_ess": {
      "avg": {
      "field": "event_sentiment_score"
      }
      }
      }
      ],
      "having": [],
      "start_date": "2017-01-01 15:30:00",
      "end_date": "2017-01-02 15:30:00"
    }'
  data = RP_APIGetDataSetJSON(APIHandler = APIHandler, payload = payload_jsonDS, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nJSON DATASET:\n", toString(data), "\n*******************************\n") )

  expect_true( is.data.table(data) )
  expect_true( nrow(data)>0 )
})


########################
# Preview of a Dataset #
########################
test_that("Preview of a Dataset", {
  payload_preview = '{
"start_date": "2017-02-01 00:00:00",
"end_date": "2017-02-10 00:00:00"
}'

  # I use dataset created in previous test
  data = RP_APIGetDataSetPreview(APIHandler = APIHandler, payload = payload_preview, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nJSON PREVIEW:\n", toString(data), "\n*******************************\n") )

  expect_true( is.data.table(data) )
  expect_true( nrow(data)>0 )
})


######################################
# Preview of a Dataset with timezone #
######################################
test_that("Preview of a Dataset with timezone", {
  payload_preview = '{
    "start_date": "2017-02-01 00:00:00",
    "end_date": "2017-02-10 00:00:00",
    "time_zone": "America/New_York"
    }'
  dataTZ = RP_APIGetDataSetPreview(APIHandler = APIHandler, payload = payload_preview, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nJSON PREVIEW TZ:\n", toString(dataTZ), "\n*******************************\n") )

  expect_true( is.data.table(dataTZ) )
  expect_true( nrow(dataTZ)>0 )
})
