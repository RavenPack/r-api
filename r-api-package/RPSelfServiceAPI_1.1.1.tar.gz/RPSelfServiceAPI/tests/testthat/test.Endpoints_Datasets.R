########################################################
# Test entrypoints for CREATING AND MANAGING DATASETS  #
#                                                      #
# It performs 5 tests:                                 #
#   1. Create new dataset                              #
#   2. List available datasets                         #
#   3. Get details for a dataset                       #
#   4. Modify existing dataset                         #
#   5. Delete a dataset                                #
#                                                      #
########################################################

context("Endpoints_Datasets")


################
# LIBRARY LOAD #
################
library(data.table)


####################
# GLOBAL VARIABLES #
####################

# Dataset UUID
datasetUUID = NULL



# ******************* DATASET TESTS START **************************************


######################
# Create new Dataset #
######################
test_that("Dataset is created", {

  # Store uuid in global env
  datasetUUID <<- RP_APICreateDataSet( APIHandler = APIHandler, payload = payload_createDS )

  cat( paste0("\n*******************************\nCREATE DS:\n", toString(datasetUUID), "\n*******************************\n") )

  expect_true( grepl( "^[0-9a-fA-F]{8}[0-9a-fA-F]{4}[0-9a-fA-F]{4}[0-9a-fA-F]{4}[0-9a-fA-F]{12}$", datasetUUID) )
  })


#####################
# List all Datasets #
#####################
test_that("List Datasets", {

  tags_list = list("Europe_Countries")
  # payload_list = list( scope = list("private","public"), tags = tags_list )
  # This is on staging only. Probably will make it to production soon.
  frequency_list = list('daily','granular')
  payload_list = list( scope = list("private","public"), tags = tags_list, frequency = frequency_list )
  dataSetList = RP_APIListDataSet( APIHandler = APIHandler, params = payload_list )

  cat( paste0("\n*******************************\nLIST DS:\n", toString(dataSetList), "\n*******************************\n") )

  expect_true( is.data.table(dataSetList) )
  expect_true( nrow(dataSetList)>0 )
  expect_true( ncol(dataSetList) == 4 )
  expect_equal( intersect(unique(dataSetList$TAGS), tags_list), tags_list )
  expect_true( length(intersect( colnames(dataSetList), c("UUID" , "NAME", "TAGS", "CREATION_TIME")))==4 )
})


#############################
# Get Details for a Dataset #
#############################
test_that("Dataset details are retrieved", {
  dsDetails = RP_APIGetDataSet( APIHandler = APIHandler, datasetUUID = datasetUUID )

  cat( paste0("\n*******************************\nDETAILS DS:\n", toString(dsDetails), "\n*******************************\n") )

  expect_true( is.character(dsDetails) )
  expect_false( is.null(dsDetails) )
})


###########################
# Modify Existing Dataset #
###########################
test_that("Dataset is modified", {

  payload_modify = '{
  "name": "Modifying RPSelfServiceAPI",
  "description": "This dataset is used for testing the Web API from R - Modified",
  "tags": [
  "Testing"
  ],
  "product": "RPA",
  "product_version": "1.0",
  "frequency": "granular",
  "fields": [
  "TIMESTAMP_UTC",
  "RP_STORY_ID",
  "RP_ENTITY_ID",
  "ENTITY_NAME"
  ],
  "filters": {
  "and": [
  {
  "RP_ENTITY_ID": {
  "in": [
  "D8442A",
  "228D42"
  ]
  }
  },
  {
  "EVENT_RELEVANCE": {
  "gte": 100
  }
  }
  ]
  }
}'

  # expect_output( out=RP_APIModifyDataSet(APIHandler = APIHandler, payload = payload_modify, datasetUUID = datasetUUID),
  #               paste0("Dataset ", datasetUUID, " successfully modified.")
  #)
  outModif = RP_APIModifyDataSet(APIHandler = APIHandler, payload = payload_modify, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nMODIF DS:\n", toString(outModif), "\n*******************************\n") )

  expect_equal( outModif, datasetUUID )
})


####################
# Delete a Dataset #
####################
test_that("Delete Dataset", {

  delOut = RP_APIDeleteDataSet( APIHandler = APIHandler, datasetUUID = datasetUUID )

  cat( paste0("\n*******************************\nDEL DS:\n", toString(delOut), "\n*******************************\n") )

  expect_false( is.null(delOut$message) )
  expect_equal( delOut$message, "Dataset deleted" )
})
