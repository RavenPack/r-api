########################################################
# Test STREAMING                                       #
#                                                      #
# Streaming data in real-time                          #
########################################################

context("Endpoints_Streaming")




# ***************************** STREAMING TESTS START *****************************************

########################
# Subscribe to a Feed  #
########################
# THIS TEST IS SKIPPED!
test_that("Subscribe to a Feed", {
  # Comment next line to execute this test!
  skip_if(TRUE)
  data = RP_APISubscribeRT(APIHandler = APIHandler, datasetUUID = "us30", funPath = "process_stream.R")
})
