########################################################
# Test entrypoints for GENERATING DATAFILES            #
#                                                      #
# It performs 4 tests:                                 #
#   1. Analytics count                                 #
#   2. Generate a data file                            #
#   3. Data file genreation job status                 #
#   4. Cancel a job                                    #
#                                                      #
########################################################

context("Endpoints_Datafiles")



################
# LIBRARY LOAD #
################

library(lubridate)


####################
# GLOBAL VARIABLES #
####################

# Dataset UUID
datasetUUID = NULL

# requestToken
requestToken = NULL





# ******************* DATAFILE TESTS START **************************************


##########################
# Generate a data File   #
##########################
test_that("Filerequest is generated", {

  # CREATE A DATASET
  # Store dsuuid in global env
  datasetUUID <<- RP_APICreateDataSet(APIHandler = APIHandler, payload = payload_createDS_DF)

  # GENERATE A DATA FILE
  payload_filerequest = '{
  "start_date": "2017-03-10 15:00:00",
  "end_date": "2017-03-15 15:00:00",
  "time_zone": "America/New_York",
  "format": "csv",
  "compressed": true,
  "notify": false
  }'

  # Store token in global env
  requestToken <<- RP_APIRequestDataFile(APIHandler = APIHandler, payload = payload_filerequest, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nGEN DF:\n", toString(requestToken), "\n*******************************\n") )

  # Request Token
  expect_true( grepl( "^[0-9a-fA-F]{8}[0-9a-fA-F]{4}[0-9a-fA-F]{4}[0-9a-fA-F]{4}[0-9a-fA-F]{12}$", requestToken$TOKEN) )
  # Expected availability
  expect_true( lubridate::is.POSIXct( lubridate::as_datetime(requestToken$ETA) )  )
})


#####################
#  Analytics Count  #
#####################
test_that("Analytics count", {
  payload_count = '{
  "start_date": "2017-01-01 00:00:00",
  "end_date": "2017-01-03 00:00:00"
}'

  rowCount = RP_APIGetDataFileCount(APIHandler = APIHandler, payload = payload_count, datasetUUID = datasetUUID)

  cat( paste0("\n*******************************\nCOUNT DF:\n", toString(rowCount), "\n*******************************\n") )

  expect_true( is.numeric(rowCount) )
  expect_true( rowCount>0 )
})


################################
#  Datafile generation Status  #
################################
test_that("Job status", {

  status = RP_APICheckFileAvailability( APIHandler = APIHandler, token = requestToken$TOKEN )

  cat( paste0("\n*******************************\nSTATUS DF:\n", toString(status), "\n*******************************\n") )

  expect_true( status$STATUS%in%c('enqueued', 'processing', 'completed', 'error') )
})


####################
# Cancel a Request #
####################
test_that("Request is cancelled", {
  serverResponse = RP_APICancelRequest(APIHandler = APIHandler, token = requestToken$TOKEN)

  cat( paste0("\n*******************************\nCANCEL DF:\n", toString(serverResponse), "\n*******************************\n") )

  # check error, the job is already completed
  expect_true( startsWith(serverResponse$errors$reason, "Bad Request: Query status is ") )
  expect_true( serverResponse$errors$type=="BadRequestError" )

  # A datafile generation job can be cancelled if the status is "enqueued"
})


