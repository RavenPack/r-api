########################################################
# Test entrypoints for ENTITIES                        #
# Querying the entity reference service                #
#                                                      #
# It performs 3 tests:                                 #
#   1. Map entity idenfifiers with RP entity universe  #
#   2. Get a reference data file                       #
#   3. Get a reference data file for a single entity   #
#                                                      #
########################################################


context("Endpoints_Entities")






# ******************* ENTITIES TESTS START **************************************

##############################################
# Map Identifiers into RavenPack Identifiers #
##############################################
test_that("Map Identifiers into RavenPack Identifiers", {
  payload_maprequest = '{
  "identifiers": [
  {
  "client_id": "12345-A",
  "date": "2017-01-01",
  "name": "Amazon Inc.",
  "entity_type": "COMP",
  "isin": "US0231351067",
  "cusip": "023135106",
  "sedol": "B58WM62",
  "listing": "XNAS:AMZN"
  }
  ]
}'

  mapData = RP_APIMappingRequest(APIHandler = APIHandler, payload = payload_maprequest)

  cat( paste0("\n*******************************\nENT MAP:\n", toString(mapData), "\n*******************************\n") )

  expect_true( is.list(mapData) )
  expect_true( length(mapData)==3 )
})


#############################
#  Get Reference data file  #
#############################
test_that("Get Reference data file", {

  params_Ref = list(entity_type = 'COMP')
  refData = RP_APIGetReferenceData(APIHandler = APIHandler, params = params_Ref)

  cat( paste0("\n*******************************\nENT REF:\n", toString(refData), "\n*******************************\n") )

  expect_true( is.character( refData) )
  expect_true( startsWith( refData, "https://")  )
})


###########################################
#  Get Reference data file for an Entity  #
###########################################
test_that("Get Reference data file for an Entity", {
  rp_entity_id = '0157B1' # Amazon
  refData = RP_APIGetEntityReference(APIHandler = APIHandler, entity_id = rp_entity_id )

  cat( paste0("\n*******************************\nENT REF ENTITY:\n", toString(refData), "\n*******************************\n") )

  expect_true( is.list(refData) )
})
