########################################################
# Test entrypoint for STATUS                           #
#                                                      #
# General status of server                             #
#                                                      #
########################################################

context("Endpoints_Status")



# ******************* STATUS TESTS START **************************************


####################
# Check API Status #
####################
test_that("API Status is OK", {
  Status = RP_APIStatus(APIHandler = APIHandler)

  cat( paste0("\n*******************************\nSTATUS:\n", toString(Status), "\n*******************************\n") )

  expect_equal(Status, "OK")
})
