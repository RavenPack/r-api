###################################################################
#  Set-up for Endpoint and APITopLevel tests                      #
#                                                                 #
# This will be executed before the execution of each test script. #
# We can define here global variables which will be used          #
# along all tests.                                                #
###################################################################


######################
# Set-up Environment #
######################

# Do not uncomment for Production level
#
# Uncomment this line for PREPRODUCTION
Sys.setenv(RPServerAPI='PREPROD')
# Uncomment this line for STAGING
# Sys.setenv(RPServerAPI='STAGING')


######################
# Create API handler #
######################
APIKey = "GrMyvEHo3GDJKbO9QlTIvY"
APIHandler = RP_CreateAPIHandler(APIKey)


####################
# GLOBAL PAYLOADS  #
####################
# Payload to create a new dataset
#NOTE. Field TIMESTAMP_LOCAL has been changed by TIMESTAMP_TZ!!!
payload_createDS = '{
  "name": "Testing RPSelfServiceAPI",
  "description": "This dataset is used for testing the Web API from R",
  "tags": [
  "Testing"
  ],
  "product": "RPA",
  "product_version": "1.0",
  "frequency": "granular",
  "fields": [
  "TIMESTAMP_TZ",
  "RP_STORY_ID",
  "RP_ENTITY_ID",
  "ENTITY_NAME"
  ],
  "filters": {
  "and": [
  {
    "RP_ENTITY_ID": {
    "in": [
    "D8442A",
    "228D42"
    ]
    }
  },
    {
    "EVENT_RELEVANCE": {
    "gte": 90
    }
    }
    ]
  }
  }'


# Payload to create a dataset for generating a DATAFILE
payload_createDS_DF = '{
    "name": "Testing RPSelfServiceAPI",
    "description": "This dataset is used for testing the Web API from R",
    "tags": [
    "Testing"
    ],
    "product": "RPA",
    "product_version": "1.0",
    "frequency": "daily",
    "fields": [
    {
    "average_ess": {
    "avg": {
    "field": "event_sentiment_score"
    }
    }
    }
    ],
    "filters": {
    "and": [
    {
    "RP_ENTITY_ID": {
    "in": [
    "D8442A"
    ]
    }
    },
    {
    "EVENT_RELEVANCE": {
    "eq": 100
    }
    }
    ]
    }}'
