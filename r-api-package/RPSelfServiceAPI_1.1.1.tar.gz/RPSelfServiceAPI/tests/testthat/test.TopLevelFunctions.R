########################################################
# Test API Top Level Functions                         #
# (available in RP_APITopLevelFunctions.R)             #
#                                                      #
# It tests:                                            #
#   - RP_APIWaitForJobCompletion                       #
#   - RP_APIDownloadFileWhenReady                      #
#                                                      #
########################################################


context("APITopLevelFunctions")


####################
# GLOBAL VARIABLES #
####################

# Create a file request
datasetUUID = RP_APICreateDataSet(APIHandler = APIHandler, payload = payload_createDS_DF)
payload_filerequest = '{
  "start_date": "2017-03-10 15:00:00",
  "end_date": "2017-03-15 15:00:00",
  "time_zone": "America/New_York",
  "format": "csv",
  "compressed": true,
  "notify": false
}'
requestToken = RP_APIRequestDataFile(APIHandler = APIHandler, payload = payload_filerequest, datasetUUID = datasetUUID)




##############################
# Datafile Generation Status #
# Wait for Job Completion    #
##############################
test_that("Datafile Generation Status", {

  JobStatus = RP_APIWaitForJobCompletion (APIHandler = APIHandler, token = requestToken$TOKEN, timeout = 60)

  cat( paste0("\n*******************************\nTopLevel wait:\n", toString(JobStatus), "\n*******************************\n") )

  expect_equal(JobStatus$STATUS, "completed")
})


############################################
# Download Datafile when Job has Completed #
############################################
test_that("Datafile is downloaded after job has completed", {

  DownloadRes = RP_APIDownloadFileWhenReady( APIHandler = APIHandler, token = requestToken$TOKEN, outputFile = 'dummy.zip', timeout = 60 )

  cat( paste0("\n*******************************\nTopLevel download:\n", toString(DownloadRes), "\n*******************************\n") )

  expect_true( DownloadRes )
  #expect_output( "File successfully downloaded!" )
  #expect_equal( DownloadRes, "File successfully downloaded!" )
})


