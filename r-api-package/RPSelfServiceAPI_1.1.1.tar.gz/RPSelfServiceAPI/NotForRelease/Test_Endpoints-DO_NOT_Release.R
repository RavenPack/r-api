# library(devtools)
# install_github("RavenPack/r-api")

library(RPSelfServiceAPI)
# Do not uncomment for Production level
#
# Uncomment this line for PREPRODUCTION
# Sys.setenv(RPServerAPI='PREPROD')
# Uncomment this line for STAGING
# Sys.setenv(RPServerAPI='STAGING')

APIKey = "GrMyvEHo3GDJKbO9QlTIvY"
APIHandler = RP_CreateAPIHandler(APIKey)
## Status
Status = RP_APIStatus(APIHandler = APIHandler)
print(Status)

## Datasets

### Create a Dataset


payload_createDS = '{
"name": "Testing RPSelfServiceAPI",
"description": "This dataset is used for testing the Web API from R",
"tags": [
"Testing"
],
"product": "RPA",
"product_version": "1.0",
"frequency": "granular",
"fields": [
"TIMESTAMP_LOCAL",
"RP_STORY_ID",
"RP_ENTITY_ID",
"ENTITY_NAME"
],
"filters": {
"and": [
{
  "RP_ENTITY_ID": {
  "in": [
  "D8442A",
  "228D42"
  ]
  }
},
  {
  "EVENT_RELEVANCE": {
  "gte": 90
  }
  }
  ]
}
}'
datasetUUID = RP_APICreateDataSet(APIHandler = APIHandler, payload = payload_createDS)
print(datasetUUID)

### List all Datasets
payload_list = list(scope = list("private","public"), tags = list("Europe Countries"))
dataSetList = RP_APIListDataSet(APIHandler = APIHandler, params = payload_list)
dataSetList

### Get Details for a Dataset

RP_APIGetDataSet(APIHandler = APIHandler, datasetUUID = datasetUUID)

### Modify an Existing Dataset

payload_modify = '{
"name": "Modifying RPSelfServiceAPI",
"description": "This dataset is used for testing the Web API from R - Modified",
"tags": [
"Testing"
],
"product": "RPA",
"product_version": "1.0",
"frequency": "granular",
"fields": [
"TIMESTAMP_UTC",
"RP_STORY_ID",
"RP_ENTITY_ID",
"ENTITY_NAME"
],
"filters": {
"and": [
{
  "RP_ENTITY_ID": {
  "in": [
  "D8442A",
  "228D42"
  ]
  }
},
  {
  "EVENT_RELEVANCE": {
  "gte": 90
  }
  }
  ]
}
}'
serverResponse = RP_APIModifyDataSet(APIHandler = APIHandler, payload = payload_modify, datasetUUID = datasetUUID)

### Delete a Dataset
serverResponse = RP_APIDeleteDataSet(APIHandler = APIHandler, datasetUUID = datasetUUID)
print(serverResponse)
## Datafiles

### Generate a data file aggregator
### Create a Dataset


payload_createDS = '{
"name": "Testing RPSelfServiceAPI",
"description": "This dataset is used for testing the Web API from R",
"tags": [
"Testing"
],
"product": "RPA",
"product_version": "1.0",
"frequency": "daily",
"fields": [
{
  "average_ess": {
  "avg": {
  "field": "event_sentiment_score"
  }
  }
}
],
"filters": {
"and": [
{
  "RP_ENTITY_ID": {
  "in": [
  "D8442A"
  ]
  }
},
  {
  "EVENT_RELEVANCE": {
  "eq": 100
  }
  }
  ]
}}'
datasetUUID = RP_APICreateDataSet(APIHandler = APIHandler, payload = payload_createDS)
print(datasetUUID)


payload_filerequest = '{
"start_date": "2017-03-10 15:00:00",
  "end_date": "2017-03-15 15:00:00",
"time_zone": "America/New_York",
"format": "csv",
"compressed": true,
"notify": false
}'
requestToken = RP_APIRequestDataFile(APIHandler = APIHandler, payload = payload_filerequest, datasetUUID = datasetUUID)
# Request Token
requestToken$TOKEN
# Expected availability
requestToken$ETA



### Analytics Count

payload_count = '{
"start_date": "2017-01-01 00:00:00",
"end_date": "2017-01-02 00:00:00"
}'
rowCount = RP_APIGetDataFileCount(APIHandler = APIHandler, payload = payload_count, datasetUUID = datasetUUID)
rowCount



### Datafile Generation Status
JobStatus = RP_APIWaitForJobCompletion (APIHandler = APIHandler, token = requestToken$TOKEN, timeout = 60)


### Download Datafile when Job has Completed
DownloadRes = RP_APIDownloadFileWhenReady(APIHandler = APIHandler, token = requestToken$TOKEN, outputFile = 'dummy.zip', timeout = 60)


### Cancel a Request
serverResponse = RP_APICancelRequest(APIHandler = APIHandler, token = requestToken$TOKEN)
## JSON Queries

### Adhoc Request for Data Daily
payload_jsonfull = '{
"product": "RPA",
"product_version": "1.0",
"frequency": "daily",
"time_zone": "America/New_York",
"fields": [
{
  "average_ess": {
  "avg": {
  "field": "event_sentiment_score"
  }
  }
}
],
"filters": {
"and": [
{
  "RP_ENTITY_ID": {
  "in": [
  "D8442A"
  ]
  }
},
  {
  "EVENT_RELEVANCE": {
  "eq": 100
  }
  }
  ]
},
  "having": [],
  "start_date": "2017-03-10 15:30:00",
  "end_date": "2017-03-15 15:30:00"
  }'
data = RP_APIGetFullAdhocJSON(APIHandler = APIHandler, payload = payload_jsonfull)
data


### Adhoc Request for Data Granular
payload_jsonfull = '{
"product": "RPA",
"product_version": "1.0",
"frequency": "granular",
"fields": [
    "TIMESTAMP_UTC",
    "RP_STORY_ID",
    "RP_ENTITY_ID",
    "ENTITY_NAME",
    "EVENT_SENTIMENT_SCORE"
  ],
"filters": {
"and": [
{
  "RP_ENTITY_ID": {
  "in": [
  "D8442A"
  ]
  }
},
  {
  "EVENT_RELEVANCE": {
  "eq": 100
  }
  }
  ]
},
  "start_date": "2017-03-10 15:30:00",
  "end_date": "2017-03-15 15:30:00"
  }'
data = RP_APIGetFullAdhocJSON(APIHandler = APIHandler, payload = payload_jsonfull)
data


### Adhoc Request for Dataset

payload_jsonDS = '{
"frequency": "daily",
"fields": [
{
  "average_ess": {
  "avg": {
  "field": "event_sentiment_score"
  }
  }
}
],
"having": [],
"start_date": "2017-01-01 15:30:00",
"end_date": "2017-01-02 15:30:00"
}'
data = RP_APIGetDataSetJSON(APIHandler = APIHandler, payload = payload_jsonDS, datasetUUID = datasetUUID)
data


### Preview of a Dataset
payload_preview = '{
"start_date": "2017-01-01 00:00:00",
"end_date": "2017-01-02 00:00:00"
}'
data = RP_APIGetDataSetPreview(APIHandler = APIHandler, payload = payload_preview, datasetUUID = datasetUUID)
data

### Preview of a Dataset with timezone
payload_preview = '{
"start_date": "2017-01-01 00:00:00",
"end_date": "2017-01-02 00:00:00",
"time_zone": "America/New_York"
}'
dataTZ = RP_APIGetDataSetPreview(APIHandler = APIHandler, payload = payload_preview, datasetUUID = datasetUUID)
dataTZ
data$TIMESTAMP_UTC
dataTZ$TIMESTAMP_UTC


## Entities
### Map Identifiers into RavenPack Identifiers
payload_maprequest = '{
"identifiers": [
{
  "client_id": "12345-A",
  "date": "2017-01-01",
  "name": "Amazon Inc.",
  "entity_type": "COMP",
  "isin": "US0231351067",
  "cusip": "023135106",
  "sedol": "B58WM62",
  "listing": "XNAS:AMZN"
}
]
}'
mapData = RP_APIMappingRequest(APIHandler = APIHandler, payload = payload_maprequest)


### Get Reference data file
params_Ref = list(entity_type = 'COMP')
refData = RP_APIGetReferenceData(APIHandler = APIHandler,params = params_Ref)
print(refData)
### Get Reference data for an Entity

rp_entity_id = '0157B1' # Amazon
refData = RP_APIGetEntityReference(APIHandler = APIHandler, entity_id = rp_entity_id )
print(refData)
## Taxonomy

### Querying the Event Taxonomy
payload_taxonomy = '{
"topics": [],
"groups": [],
"types": [],
"sub_types": [],
"properties": [],
"categories": [
"earnings-above-expectations",
"product-recall"
]
}'
taxonomyData = RP_APITaxonomy(APIHandler = APIHandler, payload = payload_taxonomy)
print(taxonomyData)
## Real Time Feed
### Subscribing to a Feed

data = RP_APISubscribeRT(APIHandler = APIHandler, datasetUUID = "us30", funPath = "process_stream.R")
